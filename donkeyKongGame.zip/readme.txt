207080185
316296839

Notes:
1. If mario jump and meet a ladder you will climb up.
2. if mario fall after jumping and meet a ladder he will stay on the ladder (until another button will be pressed).
3. Pressing 9 while playing will exit the active game and send you to the menu.
4. There are ladders without floor at the top.
5. The barrels start rolling from 2 sides randomly.


Asks for bonuses:
1. Unique animations while switching screens.
3. Except of the implementation to the random function, we havn't implemented any function
    with chatGPT (or another genAI).