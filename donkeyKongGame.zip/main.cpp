
#include "game.h"

int main() 
{
	Game donkeyKong;
	donkeyKong.run();
}








